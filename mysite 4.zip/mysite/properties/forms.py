from django import forms
from django.forms import ModelForm
from .models import properties

class propertysubmit(ModelForm):
    class Meta:
        model = properties
        fields = '__all__'


class info(forms.Form):
    Name = forms.CharField(label = "Name", max_length = 255)
    Units = forms.CharField(label= "Units", max_length = 255)
    UnitDesc = forms.CharField(label = "Unit Description", max_length = 255)
    Address = forms.CharField(label = "Address", max_length = 255)


