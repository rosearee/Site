from django.db import models

# Create your models here.
class properties(models.Model):
    Name = models.CharField(max_length = 255)
    Units = models.CharField(max_length = 255)
    UnitDesc = models.CharField(max_length = 255)
    Address = models.CharField(max_length = 255)





