from django.contrib import admin
from .models import properties


class propertiesadmin (admin.ModelAdmin):
    list_display = ("Name", "Units", "UnitDesc", "Address")

# Register your models here.
admin.site.register(properties, propertiesadmin)
