from .models import properties

class PropertyService:
    def __init__(self):
        pass

    def search_properties(self, criteria: dict):
        """
        Searches for properties based on the given criteria.

        Args:
            criteria (dict): A dictionary of search criteria 
                            (e.g., {'address': '123 Main St'}).

        Returns:
            list: A list of properties objects matching the criteria.
        """
        query = properties.objects.all()  # Start with all properties
        if 'address' in criteria:
            query = query.filter(Address__icontains=criteria['address']) #Case-insensitive search
        if 'units' in criteria:
            query = query.filter(Units=criteria['units'])
        # Add more criteria as needed
        return list(query)

    def format_property_details(self, property_object):
        """
        Formats a property object for display.

        Args:
            property_object (properties): A properties object.

        Returns:
            dict: A dictionary of formatted property details.
        """
        return {
            'name': f"Property Name: {property_object.Name}",
            'units': f"Units: {property_object.Units}",
            'unit_desc': f"Description: {property_object.UnitDesc}",
            'address': f"Address: {property_object.Address}"
        }

# You can also have standalone functions if they don't logically belong to a class
def calculate_average_units():
    """Calculates the average number of units for all properties."""
    all_properties = properties.objects.all()
    total_units = sum(int(p.Units) for p in all_properties) #Assumes Units is a number
    return total_units / all_properties.count() if all_properties.count() > 0 else 0
