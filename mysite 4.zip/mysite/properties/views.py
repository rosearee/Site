from django.shortcuts import render
from django.http import HttpResponse, HttpRequest
from django.template import loader
from .models import properties
from .forms import info, propertysubmit  # Assuming you still have propertysubmit
from django.http import HttpResponseRedirect
from .services import PropertyService, calculate_average_units  # Import services

def index(request):
    propertiesObj = properties.objects.all().values()

    if request.method == "POST":
        form = info(request.POST)
        if form.is_valid():
            # Get the cleaned data
            name = form.cleaned_data['Name']
            units = form.cleaned_data['Units']
            unit_desc = form.cleaned_data['UnitDesc']
            address = form.cleaned_data['Address']

            # Create and save the properties object
            new_property = properties(Name=name, Units=units, UnitDesc=unit_desc, Address=address)
            new_property.save()

            # Use the PropertyService to search for properties (example)
            property_service = PropertyService()
            search_criteria = {'address': form.cleaned_data['Address']}
            matching_properties = property_service.search_properties(search_criteria)

            # Format the first property's details (example)
            formatted_details = property_service.format_property_details(matching_properties[0]) if matching_properties else {}

            average_units = calculate_average_units()

            context = {
                'form_data': form.cleaned_data,
                'matching_properties': matching_properties,
                'formatted_details': formatted_details,
                'average_units': average_units,
            }
            template = loader.get_template("submitted.html")
            return HttpResponse(template.render(context, request))
    else:
        form = info()
        form2 = propertysubmit()  # Assuming you still need this
    context = {'form': form, 'form2': form2} # Corrected context

    template = loader.get_template('index.html')
    return HttpResponse(template.render(context, request))
